/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import java.util.List;
import java.util.Iterator;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 *
 * @author 
 */
public class DAO {

    /**
     * @param args the command line arguments
     */
    private static SessionFactory factory;
    private static ServiceRegistry serviceRegistry;

    public DAO(int basedatos) {
        System.err.println("Iniciando");
        try {
            Configuration configuration = new Configuration();
            System.err.println("Leyendo configuracion.");
            switch (basedatos){
                case 1:
                    configuration.configure("server.cfg.xml");
                    break;
                case 2:
                    configuration.configure("mariadb.cfg.xml");
                    break;
                case 3:
                    configuration.configure("posgrest.cfg.xml");
                    break;
            }
            serviceRegistry = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
            factory = configuration.buildSessionFactory(serviceRegistry);
        } catch (Throwable ex) {
            System.err.println("No se puede crear la Sesion" + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public void crear(){
        Session session = factory.openSession();
        session.beginTransaction();

        Ciudad uno = new Ciudad();
        uno.setDescripcion("Praga");
        session.save(uno);

        Alumno e1 = new Alumno("Alejandra", "F", 21);
        e1.setCiudad(uno);
        session.save(e1);

        Alumno e2 = new Alumno("Alexander", "F", 20);
        e2.setCiudad(uno);
        session.save(e2);

        session.getTransaction().commit();
        session.close();

    }
    
    public void getCiudad(Integer id)
    {
         Session session = factory.openSession();
         Ciudad dao=(Ciudad)session.get(Ciudad.class, id);
         List aux=dao.getAlumnos();
          //return aux;
    }
    public List  getCiudad()
    {
        Session session = factory.openSession();
        Criteria xd = session.createCriteria(Ciudad.class);
        List aux=xd.list();
        return aux;
    }
    
    public void getAlumno(Integer id)
    {
         Session session = factory.openSession();
         Alumno dao=(Alumno)session.get(Alumno.class, id);
         System.out.println("Nombre \t Sexo \t\t Edad");
         System.out.println(dao.getNombre() + "\t" +
                 dao.getSexo() +"\t\t" + dao.getEdad());
         System.out.println("Ciudad:" + dao.getCiudad().getDescripcion());
    }  

    public List getAlumnos(int edad) {
       Session session = factory.openSession();
       Criteria criteria = session.createCriteria(Alumno.class);
       criteria.add(Restrictions.eq("edad", edad));
        List empList1 = criteria.list();
        return empList1;

    }
    


}
