package persistencia;

import java.io.Serializable;
import java.util.*;


public class Ciudad
        implements Serializable {

    private Integer id;
    private String descripcion;
    private List<Alumno> Alumnos;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

   
    public List<Alumno> getAlumnos() {
        return Alumnos;
    }

    public void setAlumnos(List<Alumno>alumnos) {
        this.Alumnos = alumnos;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
