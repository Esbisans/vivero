package simple;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.cell.PropertyValueFactory;
import persistencia.Alumno;
import persistencia.Ciudad;
import persistencia.DAO;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

public class Controller implements Initializable{

    private DAO base;
    @FXML
    private Button btnTest;

    @FXML
    private ChoiceBox<Ciudad> seleccionar;

    @FXML
    private TextField buscar;

    @FXML
    private TableView<Alumno> tableAlumnos;

    @FXML
    private TableColumn ColumnaNombre;

    @FXML
    private TableColumn ColumnaCiudad;

    private ObservableList<Alumno> savealumno;

    @FXML
    void OnActionBuscar(ActionEvent event) {
        int buscar = Integer.parseInt(this.buscar.getText());
        List alumnos = base.getAlumnos(buscar);
        for (Iterator iterator =
             alumnos.iterator(); iterator.hasNext();){
            Alumno da= (Alumno) iterator.next();
            savealumno.add(da);
        }
        this.buscar.clear();
    }

    @FXML
    void OnActionSeleccionar(ActionEvent event) {
        this.savealumno.clear();
        Ciudad selec = this.seleccionar.getValue();
        List alumnos = selec.getAlumnos();
        for (Iterator iterator =
             alumnos.iterator(); iterator.hasNext();){
            Alumno da= (Alumno) iterator.next();
            savealumno.add(da);
        }
    }

    @FXML
    void OnActionMysql(ActionEvent event) {
        this.buscar.clear();
        this.savealumno.clear();
        this.seleccionar.getItems().clear();
        base = new DAO(2);
        List mariadb = base.getCiudad();
        for (Iterator iterator =
             mariadb.iterator(); iterator.hasNext();){
            Ciudad da= (Ciudad) iterator.next();
            this.seleccionar.getItems().add(da);
        }
    }

    @FXML
    void OnActionPostgre(ActionEvent event) {
        this.buscar.clear();
        this.savealumno.clear();
        this.seleccionar.getItems().clear();
        base = new DAO(3);
        List postgres = base.getCiudad();
        for (Iterator iterator =
             postgres.iterator(); iterator.hasNext();){
            Ciudad da= (Ciudad) iterator.next();
            this.seleccionar.getItems().add(da);
        }
    }

    @FXML
    void OnActionServer(ActionEvent event) {
        this.buscar.clear();
        this.savealumno.clear();
        this.seleccionar.getItems().clear();
        base = new DAO(1);
        List server = base.getCiudad();
        for (Iterator iterator =
             server.iterator(); iterator.hasNext();){
            Ciudad da= (Ciudad) iterator.next();
            this.seleccionar.getItems().add(da);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        savealumno = FXCollections.observableArrayList();
        this.ColumnaNombre.setCellValueFactory(new PropertyValueFactory("Nombre"));
        this.ColumnaCiudad.setCellValueFactory(new PropertyValueFactory("Ciudad"));
        this.tableAlumnos.setItems(savealumno);
    }
}
